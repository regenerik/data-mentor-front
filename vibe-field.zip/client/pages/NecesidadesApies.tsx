import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ArrowLeft, Upload, Download, FileSpreadsheet } from "lucide-react";

interface FilterState {
  fecha_desde: string;
  fecha_hasta: string;
  apies: string;
  canal: string;
  topico: string;
  min_caracteres: string;
  sentimiento: string;
}

export default function NecesidadesApies() {
  const [filters, setFilters] = useState<FilterState>({
    fecha_desde: "",
    fecha_hasta: "",
    apies: "",
    canal: "",
    topico: "",
    min_caracteres: "",
    sentimiento: "",
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [porcentaje, setPorcentaje] = useState(0);
  const [procesoId] = useState("demo-proceso-123");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  // Progress tracking effect
  useEffect(() => {
    if (!isProcessing) return;

    const interval = setInterval(() => {
      // Simulate progress since we don't have a real backend
      setPorcentaje((prev) => {
        if (prev >= 100) {
          setIsCompleted(true);
          setIsProcessing(false);
          clearInterval(interval);
          return 100;
        }
        return prev + Math.random() * 15;
      });

      // In real implementation, this would be:
      // fetch(`http://0.0.0.0:5000/progreso/${procesoId}`)
      //   .then(res => res.json())
      //   .then(data => {
      //     setPorcentaje(data.porcentaje);
      //     if (data.finalizado) {
      //       setIsCompleted(true);
      //       setIsProcessing(false);
      //       clearInterval(interval);
      //     }
      //   });
    }, 3000);

    return () => clearInterval(interval);
  }, [isProcessing, procesoId]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleFilterChange = (key: keyof FilterState, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = () => {
    if (!selectedFile) {
      alert("Please select an Excel file first");
      return;
    }

    setIsProcessing(true);
    setIsCompleted(false);
    setPorcentaje(0);
  };

  const handleDownload = () => {
    // In real implementation, this would download the processed file
    alert(
      "In a real implementation, this would download your processed Excel file with classified needs organized by topic.",
    );
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Link
            to="/"
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <FileSpreadsheet className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-foreground">
                Necesidades Apies
              </h1>
              <p className="text-sm text-muted-foreground">
                Customer needs analysis from service station feedback
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <Card className="border-border shadow-2xl">
          <CardHeader>
            <CardTitle className="text-foreground">
              Upload and Analyze Service Station Comments
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              With this tool, you can upload your Excel file containing comments
              from service stations and filter them to identify which ones
              express customer needs. You'll also be able to filter by Date,
              Station, Sentiment, or General Topic if applicable. The tool will
              return a classified Excel file with detected needs organized by
              topic.
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* File Upload */}
            <div className="space-y-2">
              <Label
                htmlFor="file-upload"
                className="text-foreground font-medium"
              >
                Upload your Excel file here
              </Label>
              <div className="relative">
                <Input
                  id="file-upload"
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileChange}
                  className="pl-10 bg-background"
                />
                <Upload className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
              {selectedFile && (
                <p className="text-sm text-muted-foreground">
                  Selected: {selectedFile.name}
                </p>
              )}
            </div>

            {/* Filters Section */}
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Filters
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  If you don't use these fields, all data will be processed.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Date Range */}
                <div className="space-y-2">
                  <Label htmlFor="fecha-desde" className="text-foreground">
                    Date From
                  </Label>
                  <Input
                    id="fecha-desde"
                    type="date"
                    value={filters.fecha_desde}
                    onChange={(e) =>
                      handleFilterChange("fecha_desde", e.target.value)
                    }
                    className="bg-background"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fecha-hasta" className="text-foreground">
                    Date To
                  </Label>
                  <Input
                    id="fecha-hasta"
                    type="date"
                    value={filters.fecha_hasta}
                    onChange={(e) =>
                      handleFilterChange("fecha_hasta", e.target.value)
                    }
                    className="bg-background"
                  />
                </div>

                {/* Sentiment */}
                <div className="space-y-2">
                  <Label className="text-foreground">Sentiment</Label>
                  <Select
                    value={filters.sentimiento}
                    onValueChange={(value) =>
                      handleFilterChange("sentimiento", value)
                    }
                  >
                    <SelectTrigger className="bg-background">
                      <SelectValue placeholder="Select sentiment" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="positive">Positive</SelectItem>
                      <SelectItem value="negative">Negative</SelectItem>
                      <SelectItem value="neutral">Neutral</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Station Number */}
                <div className="space-y-2">
                  <Label htmlFor="apies" className="text-foreground">
                    Station Number
                  </Label>
                  <Input
                    id="apies"
                    type="number"
                    placeholder="Enter station number"
                    value={filters.apies}
                    onChange={(e) =>
                      handleFilterChange("apies", e.target.value)
                    }
                    className="bg-background"
                  />
                </div>

                {/* Channel */}
                <div className="space-y-2">
                  <Label htmlFor="canal" className="text-foreground">
                    Channel
                  </Label>
                  <Input
                    id="canal"
                    type="text"
                    placeholder="Enter channel"
                    value={filters.canal}
                    onChange={(e) =>
                      handleFilterChange("canal", e.target.value)
                    }
                    className="bg-background"
                  />
                </div>

                {/* Topic */}
                <div className="space-y-2">
                  <Label htmlFor="topico" className="text-foreground">
                    Topic
                  </Label>
                  <Input
                    id="topico"
                    type="text"
                    placeholder="Enter topic"
                    value={filters.topico}
                    onChange={(e) =>
                      handleFilterChange("topico", e.target.value)
                    }
                    className="bg-background"
                  />
                </div>

                {/* Minimum Characters */}
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="min-caracteres" className="text-foreground">
                    Minimum Characters
                  </Label>
                  <Input
                    id="min-caracteres"
                    type="number"
                    placeholder="Enter minimum character count"
                    value={filters.min_caracteres}
                    onChange={(e) =>
                      handleFilterChange("min_caracteres", e.target.value)
                    }
                    className="bg-background max-w-xs"
                  />
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <Button
              onClick={handleSubmit}
              disabled={!selectedFile || isProcessing}
              className="w-full"
            >
              {isProcessing ? "Processing..." : "Submit"}
            </Button>

            {/* Progress Section */}
            {isProcessing && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-foreground">Processing Progress</span>
                    <span className="text-muted-foreground">
                      {Math.round(porcentaje)}%
                    </span>
                  </div>
                  <Progress value={porcentaje} className="w-full" />
                </div>
              </div>
            )}

            {/* Download Button */}
            {isCompleted && (
              <Button
                onClick={handleDownload}
                className="w-full"
                variant="default"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Result
              </Button>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
